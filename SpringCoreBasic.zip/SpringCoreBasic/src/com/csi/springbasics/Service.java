package com.csi.springbasics;

import java.util.Scanner;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Service {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter ID");
		int id=sc.nextInt();
		
		System.out.println("Enetr Name");
		String name=sc.next();
		
		System.out.println("Enter Address");
		String address=sc.next();
		
		Employee employee=(Employee) context.getBean("emp");
		employee.setEmpId(id);
		employee.setEmpName(name);
		employee.setEmpAddress(address);
		
		System.out.println(employee.getEmpId()+" "+employee.getEmpName()+" "+employee.getEmpAddress());

	}

}
