package com.csi.springlifecycle;

import org.springframework.context.support.AbstractApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Service {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		AbstractApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		
		Customer customer=(Customer) context.getBean("cust");
		
		customer.setCustId(1);
		customer.setCustName("Swapnil");
		
		System.out.println("id: "+customer.getCustId()+" Name:"+customer.getCustName());
		
		context.registerShutdownHook();

	}

}
