package com.csi.Mockito_JPA;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MockitoJpaApplication {

	public static void main(String[] args) {
		SpringApplication.run(MockitoJpaApplication.class, args);
	}

}
