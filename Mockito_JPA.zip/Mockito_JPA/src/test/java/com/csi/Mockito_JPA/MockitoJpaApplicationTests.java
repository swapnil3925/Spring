package com.csi.Mockito_JPA;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MockitoJpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
