package com.csi.springcollection;

import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

public class Product {
	
	private List productList;
	
	private Set productSet;
	
	private Map productMap;
	
	private Properties productProps;

	public List getProductList() {
		return productList;
	}

	public void setProductList(List productList) {
		this.productList = productList;
	}

	public Set getProductSet() {
		return productSet;
	}

	public void setProductSet(Set productSet) {
		this.productSet = productSet;
	}

	public Map getProductMap() {
		return productMap;
	}

	public void setProductMap(Map productMap) {
		this.productMap = productMap;
	}

	public Properties getProductProps() {
		return productProps;
	}

	public void setProductProps(Properties productProps) {
		this.productProps = productProps;
	}

}
