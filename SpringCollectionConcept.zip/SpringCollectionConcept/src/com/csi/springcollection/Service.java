package com.csi.springcollection;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Service {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		
		Product product=(Product)context.getBean("prod");
		
		System.out.println("List of Product: "+product.getProductList());
		System.out.println("Set of Product: "+product.getProductSet());
		System.out.println("Map of Product: "+product.getProductMap());
		System.out.println("Pros of Product: "+product.getProductProps());
	}

}
