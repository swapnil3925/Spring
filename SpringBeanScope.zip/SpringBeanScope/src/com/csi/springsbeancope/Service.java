package com.csi.springsbeancope;

import org.omg.CORBA.portable.ApplicationException;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Service {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ApplicationContext context=new ClassPathXmlApplicationContext("ApplicationContext.xml");
		
		Employee employee=(Employee) context.getBean("emp");
		employee.setEmpId(1);
		employee.setEmpName("Swapnil");
		
		System.out.println("Id :"+employee.getEmpId()+"\nName: "+employee.getEmpName());
		
		Employee employee2=(Employee) context.getBean("emp");
		System.out.println("Id :"+employee2.getEmpId()+"\nName: "+employee2.getEmpName());

	}

}
