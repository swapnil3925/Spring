package com.csi;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class HrmJdbcTemplateApplication {

	public static void main(String[] args) {
		SpringApplication.run(HrmJdbcTemplateApplication.class, args);
	}

}
