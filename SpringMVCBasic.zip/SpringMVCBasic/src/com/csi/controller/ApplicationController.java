package com.csi.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
@RequestMapping("/api")
public class ApplicationController {

	@RequestMapping(method=RequestMethod.GET	)
	public String sayHello(ModelMap modelMap)
	{
		modelMap.addAttribute("message", "WELCOME TO CSI");
		return "welcome";
		
	}
	
	@RequestMapping(value="/csiservice",method=RequestMethod.GET)
	public String csiService(ModelMap modelMap)
	{
		modelMap.addAttribute("message", "Full stack developer | Paymaeny Gateway Integrration | Software Development");
		return "welcome";
	}
	
	@RequestMapping(value="/csiaddress",method=RequestMethod.GET)
	public String csiAddress(ModelMap modelMap)
	{
		
		modelMap.addAttribute("message", "Inspiria mall,pcmc,mh,india");
		return "welcome";
	}
}
